//
//  PWAppOpenRequest.h
//  Pushwoosh SDK
//  (c) Pushwoosh 2012
//

#import "PWRequest.h"

@interface PWAppOpenRequest : PWRequest
@end
