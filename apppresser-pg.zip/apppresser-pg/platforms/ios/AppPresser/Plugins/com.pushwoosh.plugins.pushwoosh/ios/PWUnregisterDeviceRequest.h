//
//  PWUnregisterDeviceRequest.h
//  Pushwoosh SDK
//  (c) Pushwoosh 2013
//

#import "PWRequest.h"

@interface PWUnregisterDeviceRequest : PWRequest

@end
